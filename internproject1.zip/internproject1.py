def show_menu():
    print("==================")
    print("====== MENU ======")
    print("==================")
    print("1. Add Task")
    print("2. View Tasks")
    print("3. Remove Task")
    print("4. Exit")

def add_task(my_tasks):
    task = input("Enter the task: ")
    if task:
        my_tasks.append(task)
        print(f"Task '{task}' added.")
    else:
        print("Invalid task. Please try again.")

def view_tasks(my_tasks):
    if my_tasks:
        print("\n===== YOUR TASKS =====")
        for i, task in enumerate(my_tasks, start=1):
            print(f"{i}. {task}")
    else:
        print("No tasks to display.")

def remove_task(my_tasks):
    if my_tasks:
        view_tasks(my_tasks)
        if not my_tasks:
            return
        choice = input("Enter the number of the task to remove: ")
        if choice.isdigit():
            index = int(choice) - 1
            if 0 <= index < len(my_tasks):
                removed_task = my_tasks.pop(index)
                print(f"Task '{removed_task}' removed.")
            else:
                print("Invalid task number. Please try again.")
        else:
            print("Invalid input. Please enter a number.")

def main():
    my_tasks = []
    while True:
        show_menu()
        choice = input("Enter your choice (1-4): ")
        if choice == '1':
            add_task(my_tasks)
        elif choice == '2':
            view_tasks(my_tasks)
        elif choice == '3':
            remove_task(my_tasks)
        elif choice == '4':
            print("Exiting the program. Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()